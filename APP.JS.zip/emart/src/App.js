import './App.css';
import Home from './Component/Home';
import Navbar from './Component/Navbar';
import { witch, Routes } from 'react-router-dom';
import Products from './Component/Products';
import product from './Component/Product';


function App() {
  return (
    <>

      <Navbar />
      <witch>

        <Routes exact path="/" component={Home} />
        <Routes exact path="/products" component={Products} />
        <Routes exact path="/products/:id" component={Products} />
        <Home />

      </witch>
    </>
  );
}

export default App;
